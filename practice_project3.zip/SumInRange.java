package com.mphasis.project;
import java.util.Scanner;
public class SumInRange {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements (n): ");
        int n = scanner.nextInt();
        if (n <= 0) {
            System.out.println("Number of elements (n) should be greater than 0.");
            return;
        }
        int[] arr = new int[n];
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
            arr[i] = scanner.nextInt();
        }
        System.out.print("Enter the left range (L, 0 <= L <= n-1): ");
        int L = scanner.nextInt();
        System.out.print("Enter the right range (R, L <= R <= n-1): ");
        int R = scanner.nextInt();
        if (L < 0 || R < L || R >= n) {
            System.out.println("Invalid range inputs.");
        } else {
            int sum = findSumInRange(arr, L, R);
            System.out.println("Sum of elements in the range [" + L + ", " + R + "] is: " + sum);
        }
        scanner.close();
    }
    public static int findSumInRange(int[] arr, int L, int R) {
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}

