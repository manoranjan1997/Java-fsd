import java.util.HashMap;
import java.util.TreeMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ImplimentationOfMap {
    public static void main(String[] args) {
        // HashMap
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Alice", 30);
        hashMap.put("Bob", 25);
        hashMap.put("Charlie", 40);

        System.out.println("HashMap:");
        for (Map.Entry<String, Integer> entry : hashMap.entrySet()) {
            System.out.println("Name: " + entry.getKey() + ", Age: " + entry.getValue());
        }

        // TreeMap (sorted by keys)
        TreeMap<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Zebra", 10);
        treeMap.put("Lion", 5);
        treeMap.put("Elephant", 15);

        System.out.println("\nTreeMap (sorted by keys):");
        for (Map.Entry<String, Integer> entry : treeMap.entrySet()) {
            System.out.println("Animal: " + entry.getKey() + ", Weight: " + entry.getValue());
        }

        // LinkedHashMap (maintains insertion order)
        LinkedHashMap<Integer, String> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put(1, "One");
        linkedHashMap.put(2, "Two");
        linkedHashMap.put(3, "Three");

        System.out.println("\nLinkedHashMap (maintains insertion order):");
        for (Map.Entry<Integer, String> entry : linkedHashMap.entrySet()) {
            System.out.println("Key: " + entry.getKey() + ", Value: " + entry.getValue());
        }
    }
}
