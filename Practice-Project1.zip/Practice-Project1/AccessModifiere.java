
// A class with different access modifiers
public class AccessModifiere {
    public int publicVariable = 10;
    protected int protectedVariable = 20;
    int defaultVariable = 30; 
    private int privateVariable = 40;

    // Constructor
    public AccessModifiere() {
        System.out.println("Inside the constructor");
        System.out.println("publicVariable = " + publicVariable);
        System.out.println("protectedVariable = " + protectedVariable);
        System.out.println("defaultVariable = " + defaultVariable);
        System.out.println("privateVariable = " + privateVariable);
    }

    // A public method
    public void publicMethod() {
        System.out.println("Inside publicMethod");
    }

    // A protected method
    protected void protectedMethod() {
        System.out.println("Inside protectedMethod");
    }

    // A default method
    void defaultMethod() {
        System.out.println("Inside defaultMethod");
    }

    // A private method
    private void privateMethod() {
        System.out.println("Inside privateMethod");
    }

    public static void main(String[] args) {
        AccessModifiere example = new AccessModifiere();
        System.out.println("publicVariable = " + example.publicVariable);
        System.out.println("protectedVariable = " + example.protectedVariable);
        System.out.println("defaultVariable = " + example.defaultVariable);
        

        example.publicMethod();
        example.protectedMethod();
        example.defaultMethod();
        example.privateMethod(); 
    }
}

