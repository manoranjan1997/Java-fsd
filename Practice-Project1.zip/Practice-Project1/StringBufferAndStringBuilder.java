public class StringBufferAndStringBuilder {
    public static void main(String[] args) {
        // Create a string
        String originalString = "Hello, World!";
        System.out.println("Original String: " + originalString);

        // Convert to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);
        System.out.println("StringBuffer: " + stringBuffer);

        // Convert to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);
        System.out.println("StringBuilder: " + stringBuilder);
    }
}

