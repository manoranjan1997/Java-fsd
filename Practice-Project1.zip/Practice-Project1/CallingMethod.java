public class CallingMethod {
	//return type with argument
	double volume(double l,double b,double h) {
		double v=l*b*h;
		return v;
	}
	//Return type with no argument
	double volume1() {
		double l=5.6;
		double b=6.7;
		double h=7.8;
		double x=l*b*h;
		return x;
	}
	//no return type with argument
	void volume2(double l,double b,double h) {
		double v=l*b*h;
		System.out.println(v);
		
	}
	//No return type with no argument
	void volume3() {
		double l=5.6;
		double b=6.7;
		double h=7.8;
		double v=l*b*h;
		System.out.println(v);
	}
	public static void main(String[] args) {
		CallingMethod prg=new CallingMethod();
		double volume=prg.volume(5.6,6.7,7.8);
        System.out.println(volume);
        
        double x=prg.volume1();
		System.out.println(x);
		
		prg.volume2(5.6,6.7,7.8);
		
		prg.volume3();
	}

}
