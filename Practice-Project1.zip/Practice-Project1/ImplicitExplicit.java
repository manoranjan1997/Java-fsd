//implicit and explicit program
public class ImplicitExplicit {

	public static void main(String[] args) {
		int x=10;
		double y=x;//implicit conversion
		System.out.println(x+" "+y);
		
		double z=102.56;
		int k=(int)z;//explicit
		System.out.println(z+" "+k);
	}

}
