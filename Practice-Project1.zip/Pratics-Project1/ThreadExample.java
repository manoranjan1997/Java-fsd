package Project1;

public class ThreadExample {
    public static void main(String[] args) {
        // Creating threads using both methods
        MyThread1 thread1 = new MyThread1();
        Thread thread2 = new Thread(new MyThread2());

        // Start the threads
        thread1.start();
        thread2.start();
    }
}
