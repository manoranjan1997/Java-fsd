package PracticsProject4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class JdbcStoredProcedureExample {

    public static void main(String[] args) {
        String url = "jdbc:postgresql://localhost:5432/db3";
        String user = "root";
        String password = "345Aa147@";

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            
            String storedProcedureCall = "{CALL add_employee(?, ?, ?, ?)}";

            try (PreparedStatement statement = connection.prepareCall(storedProcedureCall)) {
                
                statement.setInt(1, 101);
                statement.setString(2, "John");
                statement.setString(3, "Doe");
                statement.setDouble(4, 50000.00);

              
                statement.execute();
                System.out.println("Stored procedure executed successfully.");
            } catch (SQLException e) {
               
                System.err.println("SQL Error: " + e.getMessage());
            }
        } catch (SQLException e) {
          
            System.err.println("Connection Error: " + e.getMessage());
        }
    }
}
