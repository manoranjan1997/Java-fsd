package com.mphasis.project;
class Node {
    int data;
    public Node next;
	public Node prev;
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}
class SinglyLinkedList {
    Node head;
    void deleteNode(int key) {
        Node current = head;
        Node prev = null;
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }
        prev.next = current.next;
    }
    void insertAtBeginning(int data) {
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }
    void printList() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
public class DeleteKeyInSinglyLinkedList {
    public static void main(String[] args) {
        SinglyLinkedList linkedList = new SinglyLinkedList();
        linkedList.insertAtBeginning(4);
        linkedList.insertAtBeginning(3);
        linkedList.insertAtBeginning(2);
        linkedList.insertAtBeginning(1);
        linkedList.insertAtBeginning(1);
        System.out.println("Original linked list:");
        linkedList.printList();
        int keyToDelete = 3;
        linkedList.deleteNode(keyToDelete);
        System.out.println("Linked list after deleting the first occurrence of " + keyToDelete + ":");
        linkedList.printList();
    }
}

