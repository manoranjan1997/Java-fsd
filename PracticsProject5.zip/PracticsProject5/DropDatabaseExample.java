package PracticsProject5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DropDatabaseExample {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/db3";
        String user = "root";
        String password = "345Aa147@";
        String databaseName = "db3";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             Statement statement = connection.createStatement()) {
            String db3 = null;
			
            String dropDatabaseSQL = "DROP DATABASE " + db3;
            statement.executeUpdate(dropDatabaseSQL);
            System.out.println("Database dropped successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
