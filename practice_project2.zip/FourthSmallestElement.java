package com.mphasis.project;
import java.util.Arrays;
import java.util.Scanner;
public class FourthSmallestElement {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of elements in the list: ");
        int n = scanner.nextInt();
        int[] unsortedList = new int[n];
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            unsortedList[i] = scanner.nextInt();
        }
        int fourthSmallest = findFourthSmallest(unsortedList);
        System.out.println("The fourth smallest element is: " + fourthSmallest);
        scanner.close();
    }
    public static int findFourthSmallest(int[] arr) {
        if (arr.length < 4) {
            System.out.println("The list does not have four elements.");
            return -1; 
        }   
        Arrays.sort(arr);
        return arr[3];
    }
}
