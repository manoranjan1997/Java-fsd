package com.mphasis.project;
class Nodeee {
    int data;
    Node next;
    Node prev;
    Nodeee(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}
class DoublyLinkedList {
    Node head;
    void insertAtEnd(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
            newNode.prev = current;
        }
    }
    void traverseForward() {
        Node current = head;
        System.out.print("Forward Traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
    void traverseBackward() {
        Node current = head;
        if (current == null) {
            System.out.println("Backward Traversal: Doubly Linked List is empty.");
            return;
        }
        while (current.next != null) {
            current = current.next;
        }
        System.out.print("Backward Traversal: ");
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.prev;
        }
        System.out.println();
    }
}
public class DoublyLinkedListTraversal {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();
        doublyList.insertAtEnd(1);
        doublyList.insertAtEnd(2);
        doublyList.insertAtEnd(3);
        doublyList.insertAtEnd(4);
        doublyList.insertAtEnd(5);
        doublyList.traverseForward();
        doublyList.traverseBackward();
    }
}

