package com.mphasis.project;
public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int steps = 5;
        System.out.println("Original Array:");
        printArray(arr);
        rightRotate(arr, steps);
        System.out.println("Array after right rotation by " + steps + " steps:");
        printArray(arr);
    }
    public static void rightRotate(int[] arr, int steps) {
        int length = arr.length;
        steps = steps % length; 

        int[] result = new int[length];

        for (int i = 0; i < length; i++) {
            int newIndex = (i + steps) % length;
            result[newIndex] = arr[i];
        }
        for (int i = 0; i < length; i++) {
            arr[i] = result[i];
        }
    }
    public static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }
        System.out.println();
    }
}
