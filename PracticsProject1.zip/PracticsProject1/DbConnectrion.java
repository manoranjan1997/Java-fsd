package PracticsProject1;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnectrion {
public static void main(String args[]) {
	
	try {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/db3","root","345Aa147@");
		if(con!=null) {
			System.out.println("Connection successfully....");
			con.close();
		}
	}catch(Exception e) {
		e.printStackTrace();
	}
}
}
