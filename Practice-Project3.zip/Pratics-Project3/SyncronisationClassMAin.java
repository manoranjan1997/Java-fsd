package Project3;

public class SyncronisationClassMAin {
	public static void main(String[] args) {
		SyncronisationClass sharedResource = new SyncronisationClass();
        Thread thread1 = new Thread(() -> sharedResource.printNumbers());
        Thread thread2 = new Thread(() -> sharedResource.printNumbers());
        thread1.setName("Thread 1");
        thread2.setName("Thread 2");
        thread1.start();
        thread2.start();
    }
}
