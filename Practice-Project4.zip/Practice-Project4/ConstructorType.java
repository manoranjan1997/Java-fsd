

public class ConstructorType {
	//default constructor
	ConstructorType(){
		int number1=10;
		int number2=20;
		int sum=number1+number2;
		System.out.println(sum);
	}
	//Parameterized constructor
	ConstructorType(int number1,int number2){
    	int sum=number1+number2;
    	System.out.println(sum);
    }
	public static void main(String[] args) {
		ConstructorType cuns=new ConstructorType();
		ConstructorType cuns1=new ConstructorType(10,20);
	}

}
