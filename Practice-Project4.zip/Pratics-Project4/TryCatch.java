package Project4;

public class TryCatch {
    public static void main(String[] args) {
        try {
            int numerator = 10;
            int denominator = 0;
            int result = numerator / denominator; 
            System.out.println("Result: " + result); 
        } catch (ArithmeticException e) {
            System.err.println("An ArithmeticException occurred: " + e.getMessage());
        }
        System.out.println("Program continues to execute.");
    }
}

