package Project5;
public class ExceptionHandling {
 public static void main(String[] args) {
     try {
         divideNumbers(10, 0);
     } catch (CustomException e) {
         System.err.println("Custom Exception: " + e.getMessage());
     } catch (ArithmeticException e) {
         System.err.println("Arithmetic Exception: " + e.getMessage());
     } finally {
         System.out.println("Finally block executed.");
     }
 }
 public static void divideNumbers(int numerator, int denominator) throws CustomException {
     if (denominator == 0) {
         throw new CustomException("Cannot divide by zero");
     }
     int result = numerator / denominator;
     System.out.println("Result: " + result);
 }
}

