package Project5;

class CustomException extends Exception {
	 public CustomException(String message) {
	     super(message);
	 }
	}
