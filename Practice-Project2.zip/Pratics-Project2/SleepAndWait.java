package Project2;

public class SleepAndWait {
	public static void main(String[] args) {
		final Object lock = new Object();
		Thread sleepThread = new Thread(() -> {
			synchronized (lock) {
				System.out.println("SleepThread is running.");
				try {
					Thread.sleep(2000); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("SleepThread has finished sleeping.");
			}
		});
		Thread waitThread = new Thread(() -> {
			synchronized (lock) {
				System.out.println("WaitThread is running.");
				try {
					lock.wait(); 
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println("WaitThread has been notified.");
			}
		});
        sleepThread.start();
		waitThread.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		synchronized (lock) {
			lock.notify();
		}

		try {
			sleepThread.join();
			waitThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        System.out.println("Both threads have finished");
	}
}

