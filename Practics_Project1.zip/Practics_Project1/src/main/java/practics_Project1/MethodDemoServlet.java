package practics_Project1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MethodDemo")
public class MethodDemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String data = request.getParameter("data");
        
        response.setContentType("text/html");
        response.getWriter().println("<h1>HTTP GET Method Demo</h1>");
        response.getWriter().println("Data received via GET: " + data);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String data = request.getParameter("data");
        
        response.setContentType("text/html");
        response.getWriter().println("<h1>HTTP POST Method Demo</h1>");
        response.getWriter().println("Data received via POST: " + data);
    }
}
