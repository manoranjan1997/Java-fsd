package Project8;

public class SimpleDemo {
	    public static void main(String[] args) {
	        // Creating objects of the Dog class
	        Dog dog1 = new Dog("Buddy", 3);
	        Dog dog2 = new Dog("Molly", 2);

	        // Accessing object properties and methods
	        System.out.println("Dog 1: " + dog1.getName() + ", Age: " + dog1.getAge());
	        dog1.bark();

	        System.out.println("Dog 2: " + dog2.getName() + ", Age: " + dog2.getAge());
	        dog2.bark();

	        // Modifying object properties using setters
	        dog1.setName("Max");
	        dog2.setAge(4);

	        System.out.println("Updated Dog 1: " + dog1.getName() + ", Age: " + dog1.getAge());
	        System.out.println("Updated Dog 2: " + dog2.getName() + ", Age: " + dog2.getAge());
	    }
	}
	
