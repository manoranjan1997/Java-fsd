package Project8;

class Dog {
    private String name;
    private int age;

    // Constructor to initialize the Dog object
    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Encapsulation: Getters and setters for private fields
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age > 0) {
            this.age = age;
        } else {
            System.out.println("Age must be a positive number.");
        }
    }

    public void bark() {
        System.out.println(name + " says Woof!");
    }
}
