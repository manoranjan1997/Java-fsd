package com.mphasis.project;
class Nodee {
    int data;
    Node next;
    Nodee(int data) {
        this.data = data;
        this.next = null;
    }
}
class CircularLinkedList {
    Node head;
    void insertSorted(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (newData <= head.data) {
            newNode.next = head;
            Node last = getLastNode();
            last.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }
    Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }
    void printList() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}
public class SortedCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();
        circularList.insertSorted(3);
        circularList.insertSorted(1);
        circularList.insertSorted(5);
        circularList.insertSorted(2);
        circularList.insertSorted(4);
        System.out.println("Sorted Circular Linked List:");
        circularList.printList();
    }
}

