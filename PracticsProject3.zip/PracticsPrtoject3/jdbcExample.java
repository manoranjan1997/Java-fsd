package PracticsPrtoject3;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class jdbcExample {
	public static void main(String[] args) {

		String url = "jdbc:mysql://localhost:3306/db3";
		String user = "root";
		String password = "345Aa147@";




		ResultSet resultSet = null;

		try {


			Connection con = DriverManager.getConnection(url, user, password);
			if(con!=null)
				System.out.println("Success...");
			Statement stmt = con.createStatement();
			stmt.executeUpdate("insert into author values(1,'Hari','a@gmail.com')");

			// Execute a SELECT query
			String sqlQuery = "SELECT * FROM author";
			resultSet = stmt.executeQuery(sqlQuery);

			// Process the result set

			while (resultSet.next()) {
				int auid = resultSet.getInt("auid");
				String auname = resultSet.getString("auname");
				String auemail=resultSet.getString("auemail");
				System.out.println("ID: " + auid + ", Name: " + auname+",email:"+auemail);

			}
			con.close();
		} catch (SQLException e) {
			System.err.println("Database connection or query execution error: " + e.getMessage());

		}
	}
}
