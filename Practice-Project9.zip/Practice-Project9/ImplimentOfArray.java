public class ImplimentOfArray {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] numbers = { 10, 20, 30, 40, 50 };

        // Calculate and print the sum of array elements
        int sum = 0;
        for (int i = 0; i < numbers.length; i++) {
            sum += numbers[i];
        }

        // Print the array elements and the sum
        System.out.println("Array elements:");
        for (int i = 0; i < numbers.length; i++) {
            System.out.println("numbers[" + i + "] = " + numbers[i]);
        }

        System.out.println("Sum of array elements: " + sum);
    }
}
