package Project9;

interface Animal {
    void speak();
}

interface Mammal extends Animal {
    void eat();
}

interface Bird extends Animal {
    void fly();
}

class Bat implements Mammal, Bird {
    @Override
    public void speak() {
        System.out.println("Bat speaks...");
    }

    @Override
    public void eat() {
        System.out.println("Bat eats insects.");
    }

    @Override
    public void fly() {
        System.out.println("Bat can fly at night.");
    }
}

public class DiamondProblemExample {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.speak();
        bat.eat();
        bat.fly();
    }
}

