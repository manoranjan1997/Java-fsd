package PracticsProject6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertRecordsExample {
    public static void main(String[] args) {
    	 String url = "jdbc:mysql://localhost:3306/db3"; 
         String user = "root";
         String password = "345Aa147@";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(
                "INSERT INTO employees (employee_id, first_name, last_name, salary) VALUES (?, ?, ?, ?)"
             )) {
           
            preparedStatement.setInt(1, 101);
            preparedStatement.setString(2, "John");
            preparedStatement.setString(3, "Doe");
            preparedStatement.setDouble(4, 50000.00);
 
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " record(s) inserted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
