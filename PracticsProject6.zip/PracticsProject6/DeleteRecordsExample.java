package PracticsProject6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteRecordsExample {
    public static void main(String[] args) {
    	 String url = "jdbc:mysql://localhost:3306/db3"; 
         String user = "root";
         String password = "345Aa147@";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(
                "DELETE FROM employees WHERE employee_id = ?"
             )) {
            
            preparedStatement.setInt(1, 101); 

            
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " record(s) deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
