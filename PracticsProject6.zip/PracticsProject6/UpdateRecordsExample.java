package PracticsProject6;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateRecordsExample {
    public static void main(String[] args) {
    	 String url = "jdbc:mysql://localhost:3306/db3"; 
         String user = "root";
         String password = "345Aa147@";

        try (Connection connection = DriverManager.getConnection(url, user, password);
             PreparedStatement preparedStatement = connection.prepareStatement(
                "UPDATE employees SET salary = ? WHERE employee_id = ?"
             )) {
            
            preparedStatement.setDouble(1, 55000.00);
            preparedStatement.setInt(2, 101); 

            
            int rowsAffected = preparedStatement.executeUpdate();
            System.out.println(rowsAffected + " record(s) updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
