public class ImplimentOfInnerClass {
    private int outerField = 10;

    // Inner class
    class InnerClass {
        void innerMethod() {
            System.out.println("Inner method: outerField = " + outerField);
        }
    }

    public void outerMethod() {
        System.out.println("Outer method");
    }

    public static void main(String[] args) {
        ImplimentOfInnerClass outerObject = new ImplimentOfInnerClass();
        
        // Create an instance of the inner class
        InnerClass innerObject = outerObject.new InnerClass();
        
        // Access inner class method
        innerObject.innerMethod();
        
        // Access outer class method
        outerObject.outerMethod();
    }
}
