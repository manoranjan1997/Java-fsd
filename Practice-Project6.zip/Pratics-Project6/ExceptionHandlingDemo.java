package Project6;

public class ExceptionHandlingDemo {
    public static void main(String[] args) {
        try {
            int[] numbers = {1, 2, 3};
            int result = divideByZero(numbers);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            System.out.println("An ArithmeticException occurred: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("An ArrayIndexOutOfBoundsException occurred: " + e.getMessage());
        } finally {
            System.out.println("This block will always execute.");
        }
    }

    public static int divideByZero(int[] numbers) {
        int result = 0;
        try {
            result = numbers[0] / (numbers[1] - numbers[2]);
        } catch (ArithmeticException e) {
            System.out.println("An ArithmeticException occurred in divideByZero method: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("An ArrayIndexOutOfBoundsException occurred in divideByZero method: " + e.getMessage());
        }
        return result;
    }
}

